$(document).ready(function () {
    $('#date').datepicker({
        format: "dd/mm/yyyy"
    });
});
